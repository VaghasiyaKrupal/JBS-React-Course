$('.owl-carousel').owlCarousel({
    items:1,
    margin:10,
    autoHeight:true
});